# En el siguiente código reemplaza la instrucción 'for' por 'times'

for i in 1..10 do
  puts i
end
