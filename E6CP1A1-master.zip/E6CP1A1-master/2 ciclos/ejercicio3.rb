# Mostrar todos los divisores del número 990 con:
# while, for, times.