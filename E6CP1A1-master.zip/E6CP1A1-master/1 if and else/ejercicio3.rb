# Hacer un refactoring, transformando las líneas de la 5 a la 7 en una sola.

a = 'X9-by'

if a == 'X9-by'
  puts 'HOLA!'
end
