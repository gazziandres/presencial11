# Hacer que el código entre en el if modificando la línea 3

a = 2
if a == 5
  puts 'La condición es verdadera.'
end
