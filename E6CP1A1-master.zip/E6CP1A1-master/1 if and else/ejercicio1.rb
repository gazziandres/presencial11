# Hacer que se cumpla la condición modificando la línea 4.

a = 2
if a == 'saludo'
  puts 'La condición es verdadera.'
end
